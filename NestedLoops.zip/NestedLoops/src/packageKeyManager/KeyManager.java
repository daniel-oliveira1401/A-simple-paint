package packageKeyManager;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyManager implements KeyListener {

    private boolean[] keys;
    public boolean startRecording,stopRecording,showDrawing,cleanMemory,cleanCanvas;


    public KeyManager(){
        init();
    }

    public void tick(){
        startRecording = keys[KeyEvent.VK_R];
        stopRecording = keys[KeyEvent.VK_S];
        showDrawing = keys[KeyEvent.VK_SPACE];
        cleanMemory = keys[KeyEvent.VK_C];
        cleanCanvas = keys[KeyEvent.VK_K];
    }

    public void init(){
        keys = new boolean[300];
    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        keys[e.getKeyCode()] = true;
    }

    @Override
    public void keyReleased(KeyEvent e) {
        keys[e.getKeyCode()] = false;
    }
}
