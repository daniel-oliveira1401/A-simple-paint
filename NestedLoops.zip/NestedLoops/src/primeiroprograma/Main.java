package primeiroprograma;

import java.awt.*;
import java.lang.reflect.Array;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        int[][] pixels = new int[800][800];
        DrawerClass drawer = new DrawerClass(pixels);

        drawer.start();

    }
}
/*
array2D[linha][coluna];

o comando array2D.length vai retornar o numero de linhas que o array possui
 */