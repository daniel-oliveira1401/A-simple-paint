package primeiroprograma;

import packageDisplay.Display;
import packageKeyManager.KeyManager;

import java.awt.*;
import java.awt.image.BufferStrategy;

public class DrawerClass extends Thread{

    private Display display;
    private KeyManager keyManager;
    private int[][] pixels;

    private boolean recording;

    private BufferStrategy bs;

    private Graphics g;

    public DrawerClass(int[][] pixels){
        this.pixels = pixels;
    }

    public void run(){
        init();
        int fps = 120;
        double tickTime = 1e9/fps;
        long now;
        long lastTime = System.nanoTime();
        long timePassed;
        while(true){
            now = System.nanoTime();
            timePassed = now - lastTime;
            if(timePassed >=tickTime){
                update();
                lastTime = now;
            }

        }
    }

    public void init(){
        this.initDisplay(800,800);
        this.initKeyManager();
        bs = display.getCanvas().getBufferStrategy();
        this.cleanMemory();
        g = bs.getDrawGraphics();
    }

    public void initDisplay(int width,int height){
        display = new Display(width,height);
        display.createDisplay();
    }

    public void initKeyManager(){
        keyManager = new KeyManager();
        display.getFrame().addKeyListener(keyManager);
    }

    public void update(){
        keyManager.tick();
        if(keyManager.cleanMemory){
            this.cleanMemory();
        }
        if(keyManager.startRecording){

            System.out.println("Started recording");
            recording = true;
        }
        if(keyManager.stopRecording){

            System.out.println("Finished recording");
            recording = false;
        }
        if(recording){
            System.out.println("Recording...");

            if(display.getCanvas().getMousePosition() != null){
                int mouseX = display.getCanvas().getMousePosition().x;
                if(display.getCanvas().getMousePosition()!=null){
                    int mouseY = display.getCanvas().getMousePosition().y;

                    pixels[mouseY][mouseX] = 1;
                }

            }

        }
        if(keyManager.cleanCanvas){
            this.cleanCanvas();
        }
        if(keyManager.showDrawing){
            if(!recording){

                showDrawing();

            }
        }
    }

    private void showDrawing() {


        g.setColor(Color.YELLOW);

        for(int l = 0;l<display.getHeight();l++){
            for(int c= 0;c<display.getWidth();c++){

                if(pixels[l][c] == 1){
                    g.fillRect(c,l,3,3);
                }

            }
        }

        bs.show();
    }

    public void cleanMemory(){
        for(int l = 0;l<display.getHeight();l++){
            for(int c= 0;c<display.getWidth();c++){

                pixels[l][c] = 0;

            }
        }
        System.out.println("Memory cleaned up :)");
    }

    public void cleanCanvas(){
        g.clearRect(0,0,800,800);
        bs.show();
        System.out.println("Canvas cleaned up");
    }

}
